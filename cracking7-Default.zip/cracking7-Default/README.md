# 100% Free + Support all bit 🐕
## Info Last Update 🎉
Bocil dilarang install 🗿, Hasil ga cp² amat masih ada Ijonya tenang aee 💩
Untuk Script Instagram menyusul 🙃 Tunggu aee
Untuk Script cracking6 ditutup, sementara pakai yang baru aee awokokokwkoekwok 🤣
# Pake doang ga follow, kondol lohh 
Logo ♥️
![deskripsi gambar](https://i.ibb.co/VQgsWZt/Screenshot-2022-07-31-07-34-14-362-com-termux.png)
Result 🔥
![deskripsi gambar](https://i.ibb.co/0cjchPw/Screenshot-2022-07-31-03-24-46-177-com-termux.png)
Gambar hanya pemanis 🐕 selebihnya cobain sendiri 💩
# Instalation
Download apk Termuxnya disini biar ngga eror🌟
[Klik Disini](https://f-droid.org/repo/com.termux_117.apk)👈
```bash
$ cd
$ pkg update && pkg upgrade
$ pkg install python git
$ pkg install play-audio
$ pip install requests mechanize
$ pip install rich bs4
$ pip install stdiomask
$ pip install --upgrade pip
$ git clone https://github.com/Al-Vino/cracking7
$ ls ( L kecil )
$ cd cracking7
$ python sister.py
```
```php
Saran metode nomor [ 2 ]
```
## Cara Update
```php
$ cd
$ cd cracking7
$ ls ( L kecil )
$ git pull
$ python sister.py
```
## MY SOCIAL MEDIA 
[![](https://img.shields.io/badge/Github-black?logo=Github&logoColor=black&labelColor=white)](https://github.com/Al-Vino) [![](https://img.shields.io/badge/Twitter-blue?logo=Twitter&logoColor=White&labelColor=white)](https://mobile.twitter.com/AdjAlvino)
[![](https://img.shields.io/badge/Facebook-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/Alvin0Xy.io)[![](https://img.shields.io/badge/Instagram-red?logo=Instagram&logoColor=red&labelColor=white)](https://www.instagram.com/mhff_xy) [![](https://img.shields.io/badge/Whatsapp-CHAT-red?logo=Whatsapp&logoColor=Brightgreen&labelColor=white)](https://wa.me/17154739342text=Halo+kak+alvino+ganteng)
## KASIH BINTANG WOY🌟🌟🌟🌟🌟🌟🌟
![Typing SVG](https://readme-typing-svg.herokuapp.com?lines=Selamat+Bersenang-senang....!+)
