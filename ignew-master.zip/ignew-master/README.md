# CRACK AKUN IG
# PERINTAH
# pkg update && pkg upgrade
# pkg install python
# pkg install git
# pip install requests
# pip install futures
# git clone https://github.com/MN4WN1-777/ignew
# cd ignew
# git pull
# python mnawn.py

