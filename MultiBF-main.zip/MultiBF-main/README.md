#### Developer Tools
- [Aang XD]()
#### Instalasi Tools
``` bash
$ pkg update && pkg upgrade
$ pkg install python git
$ pkg install play-audio
$ python -m pip install --upgrade pip
$ git clone https://github.com/AngCyber/MultiBF
$ cd MultiBF
$ ls
$ git pull
$ pip install -r multi.tools
$ python multi.py
```
#### Menu & Features Crack

![IMG_20220724_020355](https://user-images.githubusercontent.com/92802033/180619465-cdde5bac-56b6-4e5e-9608-3a653385afb9.jpg)

#### Penggunaan
``` bash
> Tools ini support pada perangkat 32bit dan 64bit
> Dan juga support pada python versi 3.10.5
> Untuk melihat versi perangkat di hp kalian ketik : uname -m
> Untuk melihat versi python di hp kalian ketik : python --version
```
[![Facebokm Badge](https://img.shields.io/badge/-aang.qwerty69-blue?style=flat&logo=Facebook&logoColor=white&link=https://www.facebook.com/aang.qwerty69/)](https://www.facebook.com/aang.qwerty69) [![Instagram Badge](https://img.shields.io/badge/-aangxd.qwerty_-f01397?style=flat&logo=Instagram&logoColor=white&link=https://www.instagram.com/aangxd.qwerty_/)](https://www.instagram.com/aangxd.qwerty_/) [![WhatsApp Badge](https://img.shields.io/badge/-6283177721763-green?style=flat&logo=WhatsApp&logoColor=white&link=https://wa.me/6283177721763/)](https://wa.me/6283177721763/) [![Saweria Badge](https://img.shields.io/badge/-AangXD-black?style=flat&logo=Saweria&logoColor=white&link=https://saweria.co/AangXD/)](https://saweria.co/AangXD)

