# Cyber_Ekonomi #

#Jangan Lupa Kasih ⭐bintang Nya 😇🙏

$ pkg install update && install upgrade

$ pkg install git

$ pkg install python2 

$ pkg install python

$ pkg install pip

$ pip install requests

$ pip install stdiomask

$ pip install mechanize

$ pip install bs4

$ pip install npm

$ pip install future

$ pip2 install mechanize

$ pip2 install requests

$ python3 -m pip install --upgrade pip

$ git clone https://github.com/IMIN-CYBER/Cyber_Ekonomi

$ ls

$ cd Cyber_Ekonomi

$ git pull

$ ls

$ python Cyber_Ekonomi.py
