# pkg update && pkg upgrade


# pkg install git


# pkg install python


# pip install requests


# pip install bs4


# pip install futures


# pip install rich


# git clone https://github.com/MN4WN1-777/FBNEW


# cd FBNEW


# git pull


# python fbnew.py
