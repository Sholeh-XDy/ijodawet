# Cyber_Mood

#Jangan Lupa Kasih ⭐bintang Nya 😇🙏

$ pkg install update && pkg install upgrade

$ cd

$ ls

$ git clone https://github.com/IMIN-CYBER/Cyber_Mood

$ cd

$ ls

$ cd Cyber_Mood

$ ls

$ python Cyber_Mood.py

#No [01] khusus FiLe, Buat DuLu Dan Pindahkan Folder ke Folde Cyber_Mood

#SEMOGA SENANG SAYANK KU 🥰😘
